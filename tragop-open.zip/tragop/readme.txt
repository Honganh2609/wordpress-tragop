/**
* Plugin Name: Trả Góp
* Plugin URI: https://phongbv378846040.wordpress.com/
* Description: Trả góp qua thẻ hoặc công ty tài chính.
* Version: 0.1
* Author: Bùi Văn Phong
* Author URI: https://phongbv378846040.wordpress.com/
**/

Plugin: Trả góp qua thẻ hoặc công ty tài chính.
Tính toán các phương thức trả góp. Gửi thông tin vào admin và gửi email cho admin & người đăng ký.

I. Intall
Sau khi cài đặt plugin, tạo 1 trang với tên Trả góp với nội dung shortcode: [install_tragop]

II. Kiểm tra trang chi tiết sản phẩm
2 nút trả góp được thêm = javascript trong <form class="cart"
có thể sửa tuỳ ý trong file tragop.js

III. Sửa tuỳ ý
Có thể sửa tuỳ ý plugin trong các file